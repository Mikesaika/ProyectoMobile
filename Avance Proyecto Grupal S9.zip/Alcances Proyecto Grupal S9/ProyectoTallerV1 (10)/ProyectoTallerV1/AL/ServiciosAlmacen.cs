﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //ALMACENA LOS SERVICIOS QUE SE INGRESAN AL PROGRAMA
{
    public class ServiciosAlmacen
    {
        private List<ItemServicio> servicios;

        public ServiciosAlmacen()
        {
            servicios = new List<ItemServicio>();
        }

        public void AñadirServicio(ItemServicio servicio)
        {
            servicios.Add(servicio);
        }

        public List<ItemServicio> ObtenerServicios()
        {
            return servicios;
        }

        public override string ToString()
        {
            return $"Servicios almacenados: {servicios.Count}";
        }
    }
}
