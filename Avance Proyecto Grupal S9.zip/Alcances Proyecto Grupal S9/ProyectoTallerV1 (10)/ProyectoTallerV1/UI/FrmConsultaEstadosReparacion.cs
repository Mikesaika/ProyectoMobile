﻿using ProyectoTallerV1.AL;
using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTallerV1.UI
{
    public partial class FrmConsultaEstadosReparacion : Form
    {
        private DataGridView dataGridViewOrders;
        private DataGridView dataGridViewDetails;
        private TextBox txtFilter;
        private Button btnFilter;
        private Button btn_cancelar;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label1;
        private List<OrdenDeReparacion> listaOrdenesTrabajo;

        public FrmConsultaEstadosReparacion()
        {
            InitializeComponent();
            // Cargar datos de ejemplo
            CargarDatos();
            // Mostrar datos en el DataGridView de órdenes
            MostrarOrdenes(listaOrdenesTrabajo);
        }

        private void InitializeComponent()
        {
            this.dataGridViewOrders = new System.Windows.Forms.DataGridView();
            this.dataGridViewDetails = new System.Windows.Forms.DataGridView();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.btnFilter = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetails)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewOrders
            // 
            this.dataGridViewOrders.Location = new System.Drawing.Point(6, 19);
            this.dataGridViewOrders.MultiSelect = false;
            this.dataGridViewOrders.Name = "dataGridViewOrders";
            this.dataGridViewOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewOrders.Size = new System.Drawing.Size(600, 200);
            this.dataGridViewOrders.TabIndex = 0;
            this.dataGridViewOrders.SelectionChanged += new System.EventHandler(this.dataGridViewOrders_SelectionChanged);
            // 
            // dataGridViewDetails
            // 
            this.dataGridViewDetails.Location = new System.Drawing.Point(4, 16);
            this.dataGridViewDetails.Name = "dataGridViewDetails";
            this.dataGridViewDetails.Size = new System.Drawing.Size(600, 200);
            this.dataGridViewDetails.TabIndex = 1;
            // 
            // txtFilter
            // 
            this.txtFilter.Location = new System.Drawing.Point(99, 14);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(200, 20);
            this.txtFilter.TabIndex = 2;
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(309, 14);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(75, 23);
            this.btnFilter.TabIndex = 3;
            this.btnFilter.Text = "Filtrar";
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.Location = new System.Drawing.Point(512, 525);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(108, 33);
            this.btn_cancelar.TabIndex = 10;
            this.btn_cancelar.Text = "&Cancelar";
            this.btn_cancelar.UseVisualStyleBackColor = true;
            this.btn_cancelar.Click += new System.EventHandler(this.btn_cancelar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridViewOrders);
            this.groupBox1.Location = new System.Drawing.Point(7, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(614, 237);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Órdenes de Reparación";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewDetails);
            this.groupBox2.Location = new System.Drawing.Point(8, 289);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(612, 230);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Detalle de órdenes de Reparación";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Código/Marca:";
            // 
            // FrmConsultaEstadosReparacion
            // 
            this.ClientSize = new System.Drawing.Size(629, 573);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.txtFilter);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "FrmConsultaEstadosReparacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consulta Estados de Reparación Celular";
            this.Load += new System.EventHandler(this.FrmConsultaOrdenesTrabajo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetails)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void CargarDatos()
        {
            // Crear datos de ejemplo
            
            listaOrdenesTrabajo = new List<OrdenDeReparacion>();
            listaOrdenesTrabajo = Global.Taller.OrdenTrabajo.ObtenerOrdenesTrabajo();

            /*listaOrdenesTrabajo = new List<OrdenDeTrabajo>            
            {
            new OrdenDeTrabajo { codigo = 1, placa = "Orden 1", Fecha = DateTime.Today,
                detalles = new List<OrdenTrabajoDetalle>
                {
                    new OrdenTrabajoDetalle { codigo = 1, Item = "Repuesto 1", Cantidad = 2, Precio = 100 },
                    new OrdenTrabajoDetalle { codigo = 1, Item = "Repuesto 2", Cantidad = 1, Precio = 150 }
                }
            },
            new OrdenDeTrabajo { codigo = 2, placa = "Orden 2", Fecha = DateTime.Today.AddDays(-1),
                detalles = new List<OrdenTrabajoDetalle>
                {
                    new OrdenTrabajoDetalle { codigo = 2, Item = "Repuesto 3", Cantidad = 3, Precio = 200 }
                }
            }
           };*/
        }

        private void MostrarOrdenes(List<OrdenDeReparacion> ordenes)
        {
            // Asignar la lista de órdenes al DataGridView
            var datosOrdenes = ordenes.Select(o => new
            {
                o.codigo,
                o.almacenamiento,
                o.sistema_operativo,
                o.marca,
                o.propietario,
                o.Fecha,
                o.TipoMantenimiento,
                o.DiagnosticoTrabajoRealizado,
                o.tecnico,
                o.Subtotal,
                o.Iva,
                o.Total
            }).ToList();

            dataGridViewOrders.DataSource = datosOrdenes;
        }

        private void MostrarDetalles(List<OrdenReparacionDetalle> detalles)
        {
            // Asignar la lista de detalles al DataGridView
            var datosDetalles = detalles.Select(d => new
            {
                d.codigo,
                d.Item,
                d.Cantidad,
                d.Precio,
                Total = d.Cantidad * d.Precio
            }).ToList();

            dataGridViewDetails.DataSource = datosDetalles;
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            /*// Obtener el filtro del TextBox
            string filtro = txtFilter.Text.ToLower();

            // Filtrar la lista de órdenes de trabajo
            var ordenesFiltradas = listaOrdenesTrabajo.Where(o =>
                o.placa.ToLower().Contains(filtro)
            ).ToList();

            // Mostrar los datos filtrados en el DataGridView de órdenes
            MostrarOrdenes(ordenesFiltradas);*/

            // Obtener el filtro del TextBox
            string filtro = txtFilter.Text.ToLower();

            // Verificar si el filtro es un número entero válido
            int idFiltro;
            bool esNumero = int.TryParse(filtro, out idFiltro);

            List<OrdenDeReparacion> ordenesFiltradas;

            if (esNumero)
            {
                // Filtrar por ID
                ordenesFiltradas = listaOrdenesTrabajo.Where(o => o.codigo == idFiltro).ToList();
            }
            else
            {
                // Filtrar por placa
                ordenesFiltradas = listaOrdenesTrabajo.Where(o =>
                    o.marca.ToLower().Contains(filtro)
                ).ToList();
            }

            // Mostrar los datos filtrados en el DataGridView de órdenes
            MostrarOrdenes(ordenesFiltradas);
        }

        private void dataGridViewOrders_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewOrders.SelectedRows.Count > 0)
            {
                // Obtener el Id de la orden seleccionada
                int ordenId = (int)dataGridViewOrders.SelectedRows[0].Cells["codigo"].Value;

                // Obtener los detalles de la orden seleccionada
                var ordenSeleccionada = listaOrdenesTrabajo.FirstOrDefault(o => o.codigo == ordenId);
                if (ordenSeleccionada != null)
                {
                    // Mostrar los detalles en el DataGridView de detalles
                    MostrarDetalles(ordenSeleccionada.detalles);
                }
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmConsultaOrdenesTrabajo_Load(object sender, EventArgs e)
        {

        }
    }
}
