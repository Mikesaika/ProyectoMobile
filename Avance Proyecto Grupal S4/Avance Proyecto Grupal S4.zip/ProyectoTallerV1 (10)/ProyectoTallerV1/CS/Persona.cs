﻿using System;

namespace ProyectoTallerVehiculosV1.CS
{
    public abstract class Persona //SUPERCLASE DEL SISTEMA CON SUS ATRBITUTOS, PROPIEDADES Y OPERACIONES DEFIINIDAS CON EXCEPCIONES
    {
        private string cedula;
        private string nombres;
        private string apellidos;
        private string telefono;
        private string email;

        public string Cedula
        {
            get { return cedula; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    cedula = value;
                }
                else
                {
                    throw new ArgumentException("La cédula no puede ser nulo o vacío.");
                }
            }
        }

        public string Nombres
        {
            get { return nombres; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    nombres = value;
                }
                else
                {
                    throw new ArgumentException("El nombre no puede ser nulo o vacío.");
                }
            }
        }

        public string Apellidos
        {
            get { return apellidos; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    apellidos = value;
                }
                else
                {
                    throw new ArgumentException("El apellido no puede ser nulo o vacío.");
                }
            }
        }

        public string Telefono
        {
            get { return telefono; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    telefono = value;
                }
                else
                {
                    throw new ArgumentException("El telefono no puede ser nulo o vacío.");
                }
            }
        }

        public string Email
        {
            get { return email; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    email = value;
                }
                else
                {
                    throw new ArgumentException("El email no puede ser nulo o vacío.");
                }
            }
        }

        public string NombreCompleto
        {
            get
            {
                return $"{nombres} {apellidos}";
            }
        }

        public override string ToString()
        {
            return NombreCompleto;
        }

    }
}
