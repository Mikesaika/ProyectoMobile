﻿namespace ProyectoTallerV1.UI
{
    partial class FrmOrdenReparacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmOrdenReparacion));
            this.groupBox_informacion = new System.Windows.Forms.GroupBox();
            this.radioButtonCorrectivo = new System.Windows.Forms.RadioButton();
            this.radioButtonPreventivo = new System.Windows.Forms.RadioButton();
            this.groupBox_diagnostico = new System.Windows.Forms.GroupBox();
            this.richTextBox_diagnostico = new System.Windows.Forms.RichTextBox();
            this.lbl_mantenimiento = new System.Windows.Forms.Label();
            this.lbl_mecanico = new System.Windows.Forms.Label();
            this.comboBox_tecnicos = new System.Windows.Forms.ComboBox();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.dateTimePicker_fecha = new System.Windows.Forms.DateTimePicker();
            this.lbl_propietario = new System.Windows.Forms.Label();
            this.txt_propietario = new System.Windows.Forms.TextBox();
            this.lbl_motor = new System.Windows.Forms.Label();
            this.txt_pantalla = new System.Windows.Forms.TextBox();
            this.lbl_fabricante = new System.Windows.Forms.Label();
            this.txt_sistema_operativo = new System.Windows.Forms.TextBox();
            this.lbl_placa = new System.Windows.Forms.Label();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.lbl_vehiculo = new System.Windows.Forms.Label();
            this.comboBox_celulares = new System.Windows.Forms.ComboBox();
            this.lbl_codigo = new System.Windows.Forms.Label();
            this.groupBox_detalleOrden = new System.Windows.Forms.GroupBox();
            this.lbl_total = new System.Windows.Forms.Label();
            this.lbl_iva = new System.Windows.Forms.Label();
            this.lbl_subtotal = new System.Windows.Forms.Label();
            this.dataGridView_detalleOrden = new System.Windows.Forms.DataGridView();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.groupBox_itemCantidad = new System.Windows.Forms.GroupBox();
            this.txt_cantidad = new System.Windows.Forms.TextBox();
            this.button_eliminar = new System.Windows.Forms.Button();
            this.button_agregar = new System.Windows.Forms.Button();
            this.comboBox_items = new System.Windows.Forms.ComboBox();
            this.txt_subtotal = new System.Windows.Forms.TextBox();
            this.txt_iva = new System.Windows.Forms.TextBox();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.label_mensajes = new System.Windows.Forms.Label();
            this.groupBox_informacion.SuspendLayout();
            this.groupBox_diagnostico.SuspendLayout();
            this.groupBox_detalleOrden.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_detalleOrden)).BeginInit();
            this.groupBox_itemCantidad.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_informacion
            // 
            this.groupBox_informacion.Controls.Add(this.radioButtonCorrectivo);
            this.groupBox_informacion.Controls.Add(this.radioButtonPreventivo);
            this.groupBox_informacion.Controls.Add(this.groupBox_diagnostico);
            this.groupBox_informacion.Controls.Add(this.lbl_mantenimiento);
            this.groupBox_informacion.Controls.Add(this.lbl_mecanico);
            this.groupBox_informacion.Controls.Add(this.comboBox_tecnicos);
            this.groupBox_informacion.Controls.Add(this.lbl_fecha);
            this.groupBox_informacion.Controls.Add(this.dateTimePicker_fecha);
            this.groupBox_informacion.Controls.Add(this.lbl_propietario);
            this.groupBox_informacion.Controls.Add(this.txt_propietario);
            this.groupBox_informacion.Controls.Add(this.lbl_motor);
            this.groupBox_informacion.Controls.Add(this.txt_pantalla);
            this.groupBox_informacion.Controls.Add(this.lbl_fabricante);
            this.groupBox_informacion.Controls.Add(this.txt_sistema_operativo);
            this.groupBox_informacion.Controls.Add(this.lbl_placa);
            this.groupBox_informacion.Controls.Add(this.txt_marca);
            this.groupBox_informacion.Controls.Add(this.lbl_vehiculo);
            this.groupBox_informacion.Controls.Add(this.comboBox_celulares);
            this.groupBox_informacion.Controls.Add(this.lbl_codigo);
            this.groupBox_informacion.Location = new System.Drawing.Point(14, 6);
            this.groupBox_informacion.Name = "groupBox_informacion";
            this.groupBox_informacion.Size = new System.Drawing.Size(552, 284);
            this.groupBox_informacion.TabIndex = 0;
            this.groupBox_informacion.TabStop = false;
            this.groupBox_informacion.Text = "Información general";
            this.groupBox_informacion.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // radioButtonCorrectivo
            // 
            this.radioButtonCorrectivo.AutoSize = true;
            this.radioButtonCorrectivo.Location = new System.Drawing.Point(223, 139);
            this.radioButtonCorrectivo.Name = "radioButtonCorrectivo";
            this.radioButtonCorrectivo.Size = new System.Drawing.Size(73, 17);
            this.radioButtonCorrectivo.TabIndex = 18;
            this.radioButtonCorrectivo.TabStop = true;
            this.radioButtonCorrectivo.Text = "Correctivo";
            this.radioButtonCorrectivo.UseVisualStyleBackColor = true;
            this.radioButtonCorrectivo.CheckedChanged += new System.EventHandler(this.radioButtonCorrectivo_CheckedChanged);
            // 
            // radioButtonPreventivo
            // 
            this.radioButtonPreventivo.AutoSize = true;
            this.radioButtonPreventivo.Location = new System.Drawing.Point(108, 139);
            this.radioButtonPreventivo.Name = "radioButtonPreventivo";
            this.radioButtonPreventivo.Size = new System.Drawing.Size(76, 17);
            this.radioButtonPreventivo.TabIndex = 17;
            this.radioButtonPreventivo.TabStop = true;
            this.radioButtonPreventivo.Text = "Preventivo";
            this.radioButtonPreventivo.UseVisualStyleBackColor = true;
            this.radioButtonPreventivo.CheckedChanged += new System.EventHandler(this.radioButtonPreventivo_CheckedChanged);
            // 
            // groupBox_diagnostico
            // 
            this.groupBox_diagnostico.Controls.Add(this.richTextBox_diagnostico);
            this.groupBox_diagnostico.Location = new System.Drawing.Point(19, 167);
            this.groupBox_diagnostico.Name = "groupBox_diagnostico";
            this.groupBox_diagnostico.Size = new System.Drawing.Size(514, 107);
            this.groupBox_diagnostico.TabIndex = 18;
            this.groupBox_diagnostico.TabStop = false;
            this.groupBox_diagnostico.Text = "Diagnóstico / Trabajos realizados";
            // 
            // richTextBox_diagnostico
            // 
            this.richTextBox_diagnostico.Location = new System.Drawing.Point(13, 20);
            this.richTextBox_diagnostico.Name = "richTextBox_diagnostico";
            this.richTextBox_diagnostico.Size = new System.Drawing.Size(488, 76);
            this.richTextBox_diagnostico.TabIndex = 5;
            this.richTextBox_diagnostico.Text = "";
            // 
            // lbl_mantenimiento
            // 
            this.lbl_mantenimiento.AutoSize = true;
            this.lbl_mantenimiento.Location = new System.Drawing.Point(24, 141);
            this.lbl_mantenimiento.Name = "lbl_mantenimiento";
            this.lbl_mantenimiento.Size = new System.Drawing.Size(79, 13);
            this.lbl_mantenimiento.TabIndex = 17;
            this.lbl_mantenimiento.Text = "Mantenimiento:";
            // 
            // lbl_mecanico
            // 
            this.lbl_mecanico.AutoSize = true;
            this.lbl_mecanico.Location = new System.Drawing.Point(310, 141);
            this.lbl_mecanico.Name = "lbl_mecanico";
            this.lbl_mecanico.Size = new System.Drawing.Size(54, 13);
            this.lbl_mecanico.TabIndex = 15;
            this.lbl_mecanico.Text = "Técnicos:";
            // 
            // comboBox_tecnicos
            // 
            this.comboBox_tecnicos.FormattingEnabled = true;
            this.comboBox_tecnicos.Location = new System.Drawing.Point(369, 138);
            this.comboBox_tecnicos.Name = "comboBox_tecnicos";
            this.comboBox_tecnicos.Size = new System.Drawing.Size(164, 21);
            this.comboBox_tecnicos.TabIndex = 4;
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Location = new System.Drawing.Point(311, 114);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(40, 13);
            this.lbl_fecha.TabIndex = 13;
            this.lbl_fecha.Text = "Fecha:";
            this.lbl_fecha.Click += new System.EventHandler(this.label8_Click);
            // 
            // dateTimePicker_fecha
            // 
            this.dateTimePicker_fecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_fecha.Location = new System.Drawing.Point(369, 110);
            this.dateTimePicker_fecha.Name = "dateTimePicker_fecha";
            this.dateTimePicker_fecha.Size = new System.Drawing.Size(164, 20);
            this.dateTimePicker_fecha.TabIndex = 2;
            // 
            // lbl_propietario
            // 
            this.lbl_propietario.AutoSize = true;
            this.lbl_propietario.Location = new System.Drawing.Point(27, 114);
            this.lbl_propietario.Name = "lbl_propietario";
            this.lbl_propietario.Size = new System.Drawing.Size(60, 13);
            this.lbl_propietario.TabIndex = 11;
            this.lbl_propietario.Text = "Propietario:";
            // 
            // txt_propietario
            // 
            this.txt_propietario.BackColor = System.Drawing.SystemColors.Window;
            this.txt_propietario.Location = new System.Drawing.Point(106, 110);
            this.txt_propietario.Name = "txt_propietario";
            this.txt_propietario.ReadOnly = true;
            this.txt_propietario.Size = new System.Drawing.Size(185, 20);
            this.txt_propietario.TabIndex = 10;
            // 
            // lbl_motor
            // 
            this.lbl_motor.AutoSize = true;
            this.lbl_motor.Location = new System.Drawing.Point(312, 86);
            this.lbl_motor.Name = "lbl_motor";
            this.lbl_motor.Size = new System.Drawing.Size(48, 13);
            this.lbl_motor.TabIndex = 9;
            this.lbl_motor.Text = "Pantalla:";
            // 
            // txt_pantalla
            // 
            this.txt_pantalla.BackColor = System.Drawing.SystemColors.Window;
            this.txt_pantalla.Location = new System.Drawing.Point(367, 83);
            this.txt_pantalla.Name = "txt_pantalla";
            this.txt_pantalla.ReadOnly = true;
            this.txt_pantalla.Size = new System.Drawing.Size(166, 20);
            this.txt_pantalla.TabIndex = 8;
            // 
            // lbl_fabricante
            // 
            this.lbl_fabricante.AutoSize = true;
            this.lbl_fabricante.Location = new System.Drawing.Point(27, 86);
            this.lbl_fabricante.Name = "lbl_fabricante";
            this.lbl_fabricante.Size = new System.Drawing.Size(55, 13);
            this.lbl_fabricante.TabIndex = 7;
            this.lbl_fabricante.Text = "Sistm Opt:";
            // 
            // txt_sistema_operativo
            // 
            this.txt_sistema_operativo.BackColor = System.Drawing.SystemColors.Window;
            this.txt_sistema_operativo.Location = new System.Drawing.Point(106, 82);
            this.txt_sistema_operativo.Name = "txt_sistema_operativo";
            this.txt_sistema_operativo.ReadOnly = true;
            this.txt_sistema_operativo.Size = new System.Drawing.Size(185, 20);
            this.txt_sistema_operativo.TabIndex = 6;
            // 
            // lbl_placa
            // 
            this.lbl_placa.AutoSize = true;
            this.lbl_placa.Location = new System.Drawing.Point(313, 63);
            this.lbl_placa.Name = "lbl_placa";
            this.lbl_placa.Size = new System.Drawing.Size(40, 13);
            this.lbl_placa.TabIndex = 5;
            this.lbl_placa.Text = "Marca:";
            // 
            // txt_marca
            // 
            this.txt_marca.BackColor = System.Drawing.SystemColors.Window;
            this.txt_marca.Location = new System.Drawing.Point(368, 57);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.ReadOnly = true;
            this.txt_marca.Size = new System.Drawing.Size(165, 20);
            this.txt_marca.TabIndex = 4;
            // 
            // lbl_vehiculo
            // 
            this.lbl_vehiculo.AutoSize = true;
            this.lbl_vehiculo.Location = new System.Drawing.Point(28, 59);
            this.lbl_vehiculo.Name = "lbl_vehiculo";
            this.lbl_vehiculo.Size = new System.Drawing.Size(42, 13);
            this.lbl_vehiculo.TabIndex = 3;
            this.lbl_vehiculo.Text = "Celular:";
            // 
            // comboBox_celulares
            // 
            this.comboBox_celulares.FormattingEnabled = true;
            this.comboBox_celulares.Location = new System.Drawing.Point(106, 56);
            this.comboBox_celulares.Name = "comboBox_celulares";
            this.comboBox_celulares.Size = new System.Drawing.Size(186, 21);
            this.comboBox_celulares.TabIndex = 1;
            this.comboBox_celulares.SelectedIndexChanged += new System.EventHandler(this.comboBox_vehiculos_SelectedIndexChanged);
            // 
            // lbl_codigo
            // 
            this.lbl_codigo.AutoSize = true;
            this.lbl_codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_codigo.Location = new System.Drawing.Point(27, 19);
            this.lbl_codigo.Name = "lbl_codigo";
            this.lbl_codigo.Size = new System.Drawing.Size(35, 25);
            this.lbl_codigo.TabIndex = 0;
            this.lbl_codigo.Text = "N°";
            this.lbl_codigo.Click += new System.EventHandler(this.lbl_codigo_Click);
            // 
            // groupBox_detalleOrden
            // 
            this.groupBox_detalleOrden.Controls.Add(this.lbl_total);
            this.groupBox_detalleOrden.Controls.Add(this.lbl_iva);
            this.groupBox_detalleOrden.Controls.Add(this.lbl_subtotal);
            this.groupBox_detalleOrden.Controls.Add(this.dataGridView_detalleOrden);
            this.groupBox_detalleOrden.Location = new System.Drawing.Point(14, 359);
            this.groupBox_detalleOrden.Name = "groupBox_detalleOrden";
            this.groupBox_detalleOrden.Size = new System.Drawing.Size(552, 243);
            this.groupBox_detalleOrden.TabIndex = 1;
            this.groupBox_detalleOrden.TabStop = false;
            this.groupBox_detalleOrden.Text = "Detalle de órden";
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(366, 215);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(34, 13);
            this.lbl_total.TabIndex = 16;
            this.lbl_total.Text = "Total:";
            // 
            // lbl_iva
            // 
            this.lbl_iva.AutoSize = true;
            this.lbl_iva.Location = new System.Drawing.Point(366, 193);
            this.lbl_iva.Name = "lbl_iva";
            this.lbl_iva.Size = new System.Drawing.Size(27, 13);
            this.lbl_iva.TabIndex = 2;
            this.lbl_iva.Text = "IVA:";
            // 
            // lbl_subtotal
            // 
            this.lbl_subtotal.AutoSize = true;
            this.lbl_subtotal.Location = new System.Drawing.Point(366, 167);
            this.lbl_subtotal.Name = "lbl_subtotal";
            this.lbl_subtotal.Size = new System.Drawing.Size(49, 13);
            this.lbl_subtotal.TabIndex = 1;
            this.lbl_subtotal.Text = "Subtotal:";
            // 
            // dataGridView_detalleOrden
            // 
            this.dataGridView_detalleOrden.AllowUserToAddRows = false;
            this.dataGridView_detalleOrden.AllowUserToDeleteRows = false;
            this.dataGridView_detalleOrden.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_detalleOrden.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Descripcion,
            this.Precio,
            this.Cantidad,
            this.Total});
            this.dataGridView_detalleOrden.Location = new System.Drawing.Point(12, 19);
            this.dataGridView_detalleOrden.Name = "dataGridView_detalleOrden";
            this.dataGridView_detalleOrden.ReadOnly = true;
            this.dataGridView_detalleOrden.Size = new System.Drawing.Size(527, 137);
            this.dataGridView_detalleOrden.TabIndex = 10;
            this.dataGridView_detalleOrden.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_detalleOrden_CellValueChanged);
            this.dataGridView_detalleOrden.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dataGridView_detalleOrden_RowsAdded);
            this.dataGridView_detalleOrden.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridView_detalleOrden_RowsRemoved);
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Descripción";
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.ReadOnly = true;
            this.Descripcion.Width = 250;
            // 
            // Precio
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = null;
            this.Precio.DefaultCellStyle = dataGridViewCellStyle1;
            this.Precio.HeaderText = "Precio unitario";
            this.Precio.Name = "Precio";
            this.Precio.ReadOnly = true;
            this.Precio.Width = 80;
            // 
            // Cantidad
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Cantidad.DefaultCellStyle = dataGridViewCellStyle2;
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.ReadOnly = true;
            this.Cantidad.Width = 70;
            // 
            // Total
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "C2";
            dataGridViewCellStyle3.NullValue = null;
            this.Total.DefaultCellStyle = dataGridViewCellStyle3;
            this.Total.HeaderText = "Total";
            this.Total.Name = "Total";
            this.Total.ReadOnly = true;
            this.Total.Width = 80;
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.Location = new System.Drawing.Point(457, 606);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(108, 33);
            this.btn_cancelar.TabIndex = 12;
            this.btn_cancelar.Text = "&Cancelar";
            this.btn_cancelar.UseVisualStyleBackColor = true;
            this.btn_cancelar.Click += new System.EventHandler(this.btn_cancelar_Click);
            // 
            // btn_guardar
            // 
            this.btn_guardar.Location = new System.Drawing.Point(343, 606);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(108, 33);
            this.btn_guardar.TabIndex = 11;
            this.btn_guardar.Text = "&Guardar";
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // groupBox_itemCantidad
            // 
            this.groupBox_itemCantidad.Controls.Add(this.txt_cantidad);
            this.groupBox_itemCantidad.Controls.Add(this.button_eliminar);
            this.groupBox_itemCantidad.Controls.Add(this.button_agregar);
            this.groupBox_itemCantidad.Controls.Add(this.comboBox_items);
            this.groupBox_itemCantidad.Location = new System.Drawing.Point(14, 293);
            this.groupBox_itemCantidad.Name = "groupBox_itemCantidad";
            this.groupBox_itemCantidad.Size = new System.Drawing.Size(552, 68);
            this.groupBox_itemCantidad.TabIndex = 12;
            this.groupBox_itemCantidad.TabStop = false;
            this.groupBox_itemCantidad.Text = "Seleccione un ítem e indique la cantidad";
            // 
            // txt_cantidad
            // 
            this.txt_cantidad.Location = new System.Drawing.Point(369, 27);
            this.txt_cantidad.Name = "txt_cantidad";
            this.txt_cantidad.Size = new System.Drawing.Size(68, 20);
            this.txt_cantidad.TabIndex = 7;
            // 
            // button_eliminar
            // 
            this.button_eliminar.Image = ((System.Drawing.Image)(resources.GetObject("button_eliminar.Image")));
            this.button_eliminar.Location = new System.Drawing.Point(492, 16);
            this.button_eliminar.Name = "button_eliminar";
            this.button_eliminar.Size = new System.Drawing.Size(47, 40);
            this.button_eliminar.TabIndex = 9;
            this.button_eliminar.UseVisualStyleBackColor = true;
            this.button_eliminar.Click += new System.EventHandler(this.button_eliminar_Click);
            // 
            // button_agregar
            // 
            this.button_agregar.Image = ((System.Drawing.Image)(resources.GetObject("button_agregar.Image")));
            this.button_agregar.Location = new System.Drawing.Point(443, 16);
            this.button_agregar.Name = "button_agregar";
            this.button_agregar.Size = new System.Drawing.Size(47, 40);
            this.button_agregar.TabIndex = 8;
            this.button_agregar.UseVisualStyleBackColor = true;
            this.button_agregar.Click += new System.EventHandler(this.button_agregar_Click);
            // 
            // comboBox_items
            // 
            this.comboBox_items.FormattingEnabled = true;
            this.comboBox_items.Location = new System.Drawing.Point(13, 27);
            this.comboBox_items.Name = "comboBox_items";
            this.comboBox_items.Size = new System.Drawing.Size(350, 21);
            this.comboBox_items.TabIndex = 6;
            this.comboBox_items.SelectedIndexChanged += new System.EventHandler(this.comboBox_items_SelectedIndexChanged);
            // 
            // txt_subtotal
            // 
            this.txt_subtotal.BackColor = System.Drawing.SystemColors.Window;
            this.txt_subtotal.Location = new System.Drawing.Point(449, 522);
            this.txt_subtotal.Name = "txt_subtotal";
            this.txt_subtotal.ReadOnly = true;
            this.txt_subtotal.Size = new System.Drawing.Size(102, 20);
            this.txt_subtotal.TabIndex = 13;
            this.txt_subtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_iva
            // 
            this.txt_iva.BackColor = System.Drawing.SystemColors.Window;
            this.txt_iva.Location = new System.Drawing.Point(449, 548);
            this.txt_iva.Name = "txt_iva";
            this.txt_iva.ReadOnly = true;
            this.txt_iva.Size = new System.Drawing.Size(102, 20);
            this.txt_iva.TabIndex = 14;
            this.txt_iva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_total
            // 
            this.txt_total.BackColor = System.Drawing.SystemColors.Window;
            this.txt_total.Location = new System.Drawing.Point(450, 574);
            this.txt_total.Name = "txt_total";
            this.txt_total.ReadOnly = true;
            this.txt_total.Size = new System.Drawing.Size(102, 20);
            this.txt_total.TabIndex = 15;
            this.txt_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label_mensajes
            // 
            this.label_mensajes.AutoSize = true;
            this.label_mensajes.Location = new System.Drawing.Point(18, 615);
            this.label_mensajes.Name = "label_mensajes";
            this.label_mensajes.Size = new System.Drawing.Size(0, 13);
            this.label_mensajes.TabIndex = 16;
            // 
            // FrmOrdenReparacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 644);
            this.Controls.Add(this.label_mensajes);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_iva);
            this.Controls.Add(this.txt_subtotal);
            this.Controls.Add(this.groupBox_itemCantidad);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.groupBox_detalleOrden);
            this.Controls.Add(this.groupBox_informacion);
            this.MaximizeBox = false;
            this.Name = "FrmOrdenReparacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nueva órden de Reparación Celular";
            this.Load += new System.EventHandler(this.FrmOrdenTrabajo_Load);
            this.groupBox_informacion.ResumeLayout(false);
            this.groupBox_informacion.PerformLayout();
            this.groupBox_diagnostico.ResumeLayout(false);
            this.groupBox_detalleOrden.ResumeLayout(false);
            this.groupBox_detalleOrden.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_detalleOrden)).EndInit();
            this.groupBox_itemCantidad.ResumeLayout(false);
            this.groupBox_itemCantidad.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_informacion;
        private System.Windows.Forms.Label lbl_codigo;
        private System.Windows.Forms.GroupBox groupBox_detalleOrden;
        private System.Windows.Forms.Label lbl_placa;
        private System.Windows.Forms.TextBox txt_marca;
        private System.Windows.Forms.Label lbl_vehiculo;
        private System.Windows.Forms.ComboBox comboBox_celulares;
        private System.Windows.Forms.Label lbl_fabricante;
        private System.Windows.Forms.TextBox txt_sistema_operativo;
        private System.Windows.Forms.Label lbl_propietario;
        private System.Windows.Forms.TextBox txt_propietario;
        private System.Windows.Forms.Label lbl_motor;
        private System.Windows.Forms.TextBox txt_pantalla;
        private System.Windows.Forms.Label lbl_mecanico;
        private System.Windows.Forms.ComboBox comboBox_tecnicos;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.DateTimePicker dateTimePicker_fecha;
        private System.Windows.Forms.GroupBox groupBox_diagnostico;
        private System.Windows.Forms.RichTextBox richTextBox_diagnostico;
        private System.Windows.Forms.Label lbl_mantenimiento;
        private System.Windows.Forms.DataGridView dataGridView_detalleOrden;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.GroupBox groupBox_itemCantidad;
        private System.Windows.Forms.Button button_eliminar;
        private System.Windows.Forms.Button button_agregar;
        private System.Windows.Forms.ComboBox comboBox_items;
        private System.Windows.Forms.TextBox txt_cantidad;
        private System.Windows.Forms.Label lbl_iva;
        private System.Windows.Forms.Label lbl_subtotal;
        private System.Windows.Forms.TextBox txt_subtotal;
        private System.Windows.Forms.TextBox txt_iva;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Precio;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        private System.Windows.Forms.RadioButton radioButtonCorrectivo;
        private System.Windows.Forms.RadioButton radioButtonPreventivo;
        private System.Windows.Forms.Label label_mensajes;
    }
}