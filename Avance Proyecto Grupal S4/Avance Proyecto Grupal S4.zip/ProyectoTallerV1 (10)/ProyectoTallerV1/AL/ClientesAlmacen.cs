﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //ALMACENA LOS TIPOS DE MANTENIMIENTO QUE SE INGRESAN AL PROGRAMA
{
    public class ClientesAlmacen
    {
        private List<Cliente> clientes;

        public ClientesAlmacen()
        {
            clientes = new List<Cliente>();
        }

        public void AñadirCliente(Cliente cliente)
        {
            clientes.Add(cliente);
        }

        public List<Cliente> ObtenerClientes()
        {
            return clientes;
        }

        public override string ToString()
        {
            return $"Clientes almacenados: {clientes.Count}";
        }
    }
}
