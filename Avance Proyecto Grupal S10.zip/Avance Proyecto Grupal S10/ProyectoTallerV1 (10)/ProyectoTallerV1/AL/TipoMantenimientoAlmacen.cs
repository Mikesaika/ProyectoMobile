﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //ALMACENA LOS TIPOS DE MANTENIMIENTO QUE SE INGRESAN AL PROGRAMA
{
    public class TipoMantenimientoAlmacen
    {
        private List<TipoMantenimiento> tipo_mantenimiento;

        public TipoMantenimientoAlmacen()
        {
            tipo_mantenimiento = new List<TipoMantenimiento>();
        }

        public void AñadirTipoMantenimiento(TipoMantenimiento tipo_mantenimiento)
        {
            this.tipo_mantenimiento.Add(tipo_mantenimiento);
        }

        public List<TipoMantenimiento> ObtenerTiposMantenimiento()
        {
            return tipo_mantenimiento;
        }

        public override string ToString()
        {
            return $"{tipo_mantenimiento.Count}";
        }
    }
}
