﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //ALMACENA CELULARES QUE SE INGRESAN AL PROGRAMA
{
    public class CelularesAlmacen
    {
        private List<Celular> celulares;

        public CelularesAlmacen()
        {
            celulares = new List<Celular>();
        }

        public void AñadirVehiculo(Celular celular)
        {
            celulares.Add(celular);
        }

        public List<Celular> ObtenerVehiculos()
        {
            return celulares;
        }

        public override string ToString()
        {
            return $"{celulares.Count}";
        }
    }
}
