﻿namespace ProyectoTallerVehiculosV1.CS
{
    public class TipoMantenimiento //CLASE DE LOS TIPOS DE MANTENIMIENTO (REPUESTO, SERVICIO) CON SU ATRIBUTO DESCRIPCION Y PROPIEDADES
    {
        //public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
