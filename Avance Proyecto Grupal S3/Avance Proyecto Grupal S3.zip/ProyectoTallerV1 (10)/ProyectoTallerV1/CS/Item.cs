﻿using System;

namespace ProyectoTallerVehiculosV1.CS
{
    public abstract class Item //CLASE ITEM QUE CONTIENE ITEMREPUESTO E ITEMSERVICIO SON SUS ATRIBUTOS Y SOBREESCRITURA PARA MOSTRAR INFORMACION
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }

        public string TipoItem {  get; set; }   

        /*protected Item(string nombre, double precio)
        {
            if (string.IsNullOrWhiteSpace(nombre))
            {
                throw new ArgumentException("El nombre no puede estar vacío.", nameof(nombre));
            }

            if (precio <= 0)
            {
                throw new ArgumentException("El precio debe ser mayor que cero.", nameof(precio));
            }

            Nombre = nombre;
            Precio = precio;
        }*/

        public virtual void MostrarInformacion()
        {
            Console.WriteLine($"Nombre: {Nombre}, Precio: {Precio:C}");
        }
    }
}
