﻿using ProyectoTallerV1.AL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTallerV1
{
    public static class Global
    {
        public static Taller Taller = new Taller();
        public const double IVA = 15;
        public static int secuencia=0;
        public static void LimpiarControles(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Clear();
                }
                else if (control is ComboBox)
                {
                    ((ComboBox)control).SelectedIndex = -1;
                }
                else if (control is CheckBox)
                {
                    ((CheckBox)control).Checked = false;
                }
                else if (control is RadioButton)
                {
                    ((RadioButton)control).Checked = false;
                }
                else if (control is ListBox)
                {
                    ((ListBox)control).ClearSelected();
                }
                else if (control is RichTextBox)
                {
                    ((RichTextBox)control).Text = string.Empty;
                }
                else if (control is DataGridView)
                {
                    ((DataGridView)control).Rows.Clear();
                }
                // Llamada recursiva para limpiar controles dentro de contenedores
                if (control.HasChildren)
                {
                    LimpiarControles(control);
                }
            }
        }
    }    
}
