﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //CLASE TALLER CON SUS ATRIBUTOS, ASOCIACION, PROPIEDADES Y OPERACION 
{
    public class Taller
    {
        public CelularesAlmacen Celulares { get; set; }
        public ClientesAlmacen Clientes { get; set; }
        public TecnicosAlmacen Tecnicos { get; set; }
        public TipoMantenimientoAlmacen TipoMantenimiento { get; set; }
        public RepuestosAlmacen Repuestos { get; set; }
        public ServiciosAlmacen Servicios { get; set; }

        public OrdenTrabajoAlmacen OrdenTrabajo { get; set; }

        public Taller()
        {
            Celulares = new CelularesAlmacen();
            Clientes = new ClientesAlmacen();
            Tecnicos = new TecnicosAlmacen();
            TipoMantenimiento = new TipoMantenimientoAlmacen();
            Repuestos = new RepuestosAlmacen();
            Servicios = new ServiciosAlmacen();
            OrdenTrabajo = new OrdenTrabajoAlmacen();
        }

        public override string ToString()
        {
            return $"Reparación con {Clientes} clientes, {Celulares} celulares y {Servicios} servicios.";
        }
    }
}
