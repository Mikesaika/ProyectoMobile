﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL
{
    public class OrdenTrabajoAlmacen //ALMACENA LAS ORDENES DE TRABAJO QUE SE INGRESAN AL PROGRAMA
    {
        private List<OrdenDeReparacion> ordenDeTrabajos;

        public OrdenTrabajoAlmacen()
        {
            ordenDeTrabajos = new List<OrdenDeReparacion>();
        }

        public void AñadirOrdenTrabajo(OrdenDeReparacion ordenDeTrabajos)
        {
            this.ordenDeTrabajos.Add(ordenDeTrabajos);
        }

        public List<OrdenDeReparacion> ObtenerOrdenesTrabajo()
        {
            return ordenDeTrabajos;
        }

        public override string ToString()
        {
            return $"{ordenDeTrabajos.Count}";
        }
    }
}
