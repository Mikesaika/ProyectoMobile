﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //ALMACENA LOSREPUESTOS QUE SE INGRESAN AL PROGRAMA
{
    public class RepuestosAlmacen
    {
        private List<ItemRepuesto> repuestos;

        public RepuestosAlmacen()
        {
            repuestos = new List<ItemRepuesto>();
        }

        public void AñadirRepuesto(ItemRepuesto repuesto)
        {
            repuestos.Add(repuesto);
        }

        public List<ItemRepuesto> ObtenerRepuestos()
        {
            return repuestos;
        }

        public override string ToString()
        {
            return $"Repuestos almacenados: {repuestos.Count}";
        }
    }
}
