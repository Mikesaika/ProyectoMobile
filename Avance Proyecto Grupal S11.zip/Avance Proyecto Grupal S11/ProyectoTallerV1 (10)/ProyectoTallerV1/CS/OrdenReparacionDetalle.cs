﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerVehiculosV1.CS //CLASE DEL DETALLE DE ORDENES DR REPARACION CON SUS ATRIBUTOS Y PROPIEDADES
{
    public class OrdenReparacionDetalle
    {
        public int codigo {  get; set; }
        public string Item { get; set; }

        public double Precio { get; set; }

        public int Cantidad { get; set; }

        public double Total { get; set; }   
    }
}
