﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoTallerV1.UI
{
    public partial class FrmTipoMantenimiento : Form
    {
        public FrmTipoMantenimiento()
        {
            InitializeComponent();
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            TipoMantenimiento tipo_mantenimiento = new TipoMantenimiento();
            try
            {
                tipo_mantenimiento.Descripcion = txt_descripcion.Text;                

                //Almacenamiento
                Global.Taller.TipoMantenimiento.AñadirTipoMantenimiento(tipo_mantenimiento);
                MessageBox.Show("Tipo de mantenimiento almacenado correctamente...");
                Global.LimpiarControles(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
