﻿using ProyectoTallerVehiculosV1.CS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoTallerV1.AL //ALMACENA LOS TECNICOS QUE SE INGRESAN AL PROGRAMA
{
    public class TecnicosAlmacen
    {
        private List<Tecnico> tecnicos;

        public TecnicosAlmacen()
        {
            tecnicos = new List<Tecnico>();
        }

        public void AñadirMecanico(Tecnico tecnico)
        {
            tecnicos.Add(tecnico);
        }

        public List<Tecnico> ObtenerMecanicos()
        {
            return tecnicos;
        }

        public override string ToString()
        {
            return $"Técnicos almacenados: {tecnicos.Count}";
        }
    }
}
